﻿using System;
using System.Drawing;
using System.Windows.Forms;
using dnlib.DotNet.Emit;

namespace Shadow-Crypt
{
    partial class MainFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private void comboBoxAVBypass_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedAV = comboBoxAVBypass.SelectedItem.ToString();
            MessageBox.Show("Selected AV bypass: " + selectedAV);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrm));
            this.labelAVBypass = new System.Windows.Forms.Label();
            this.comboBoxAVBypass = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.topPanel = new System.Windows.Forms.Panel();
            int checkboxStartY = 495;
            checkboxStartY += 15;

            // Hacker theme styling
            this.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackColor = System.Drawing.Color.Black;
            this.ForeColor = System.Drawing.Color.Lime;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));

            // labelAVBypass
            this.labelAVBypass.AutoSize = true;
            this.labelAVBypass.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.labelAVBypass.ForeColor = System.Drawing.Color.Cyan;
            this.labelAVBypass.Location = new System.Drawing.Point(24, 400);
            this.labelAVBypass.Name = "labelAVBypass";
            this.labelAVBypass.Size = new System.Drawing.Size(136, 17);
            this.labelAVBypass.TabIndex = 1;
            this.labelAVBypass.Text = "CHOOSE AV BYPASS:";

            // comboBoxAVBypass
            this.comboBoxAVBypass.BackColor = System.Drawing.Color.Black;
            this.comboBoxAVBypass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxAVBypass.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxAVBypass.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.comboBoxAVBypass.ForeColor = System.Drawing.Color.Lime;
            this.comboBoxAVBypass.FormattingEnabled = true;
            this.comboBoxAVBypass.Items.AddRange(new object[] {
                "SentinelOne",
                "SentinelOne Singularity",
                "Sophos Intercept",
                "McAfee Total Protection",
                "McAfee MVISION EDR",
                "Kaspersky Antivirus",
                "Avast Antivirus",
                "Bitdefender",
                "ESET NOD32",
                "Bitdefender GravityZone EDR",
                "Cisco Secure Endpoint",
                "Trend Micro Apex One",
                "Carbon Black",
                "CrowdStrike Falcon",
                "Norton Antivirus",
                "Windows Defender"});
            this.comboBoxAVBypass.Location = new System.Drawing.Point(28, 425);
            this.comboBoxAVBypass.Name = "comboBoxAVBypass";
            this.comboBoxAVBypass.Size = new System.Drawing.Size(381, 23);
            this.comboBoxAVBypass.TabIndex = 2;
            this.comboBoxAVBypass.SelectedIndexChanged += new System.EventHandler(this.comboBoxAVBypass_SelectedIndexChanged);

            this.ClientSize = new System.Drawing.Size(446, 750);
            this.label1 = new System.Windows.Forms.Label();
            this.topPanel = new System.Windows.Forms.Panel();

            this.sleepNum = new System.Windows.Forms.NumericUpDown();
            this.assemblyBtn = new System.Windows.Forms.Button();
            this.buildBtn = new System.Windows.Forms.Button();
            this.sleepChk = new System.Windows.Forms.CheckBox();
            this.antiVM = new System.Windows.Forms.CheckBox();
            this.amsiBox = new System.Windows.Forms.CheckBox();
            this.schtasksChk = new System.Windows.Forms.CheckBox();
            this.regeditChk = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.runpeTypeBox = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.encryptionTypeBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.regeditNameTxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.schtasksNameTxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.foldernameTxt = new System.Windows.Forms.TextBox();
            this.specialBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.filenameTxt = new System.Windows.Forms.TextBox();
            this.browsePayloadBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.payloadTxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.exitBox = new System.Windows.Forms.PictureBox();
            this.minimizeBox = new System.Windows.Forms.PictureBox();
            this.topPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sleepNum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBox)).BeginInit();
            this.SuspendLayout();

            // label1
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("OCR A Extended", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Cyan;
            this.label1.Location = new System.Drawing.Point(12, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "SHADOW-CRYPT";

            // topPanel
            this.topPanel.BackColor = System.Drawing.Color.Black;
            this.topPanel.Controls.Add(this.labelAVBypass);
            this.topPanel.Controls.Add(this.comboBoxAVBypass);
            this.topPanel.Controls.Add(this.sleepNum);
            this.topPanel.Controls.Add(this.assemblyBtn);
            this.topPanel.Controls.Add(this.buildBtn);
            this.topPanel.Controls.Add(this.sleepChk);
            this.topPanel.Controls.Add(this.antiVM);
            this.topPanel.Controls.Add(this.amsiBox);
            this.topPanel.Controls.Add(this.schtasksChk);
            this.topPanel.Controls.Add(this.regeditChk);
            this.topPanel.Controls.Add(this.runpeTypeBox);
            this.topPanel.Controls.Add(this.label11);
            this.topPanel.Controls.Add(this.encryptionTypeBox);
            this.topPanel.Controls.Add(this.label10);
            this.topPanel.Controls.Add(this.label9);
            this.topPanel.Controls.Add(this.regeditNameTxt);
            this.topPanel.Controls.Add(this.label8);
            this.topPanel.Controls.Add(this.schtasksNameTxt);
            this.topPanel.Controls.Add(this.label7);
            this.topPanel.Controls.Add(this.foldernameTxt);
            this.topPanel.Controls.Add(this.specialBox);
            this.topPanel.Controls.Add(this.label6);
            this.topPanel.Controls.Add(this.label5);
            this.topPanel.Controls.Add(this.filenameTxt);
            this.topPanel.Controls.Add(this.browsePayloadBtn);
            this.topPanel.Controls.Add(this.label4);
            this.topPanel.Controls.Add(this.payloadTxt);
            this.topPanel.Controls.Add(this.exitBox);
            this.topPanel.Controls.Add(this.minimizeBox);
            this.topPanel.Controls.Add(this.label1);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.topPanel.ForeColor = System.Drawing.Color.Lime;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(446, 750);
            this.topPanel.TabIndex = 1;
            this.topPanel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.topPanel_MouseDown);
            this.topPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.topPanel_MouseMove);
            this.topPanel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.topPanel_MouseUp);

            // Footer label
            Label labelFooter = new Label();
            labelFooter.AutoSize = true;
            labelFooter.Font = new Font("Consolas", 10F, FontStyle.Bold);
            labelFooter.ForeColor = Color.Cyan;
            labelFooter.Location = new Point(28, 685);
            labelFooter.Name = "labelFooter";
            labelFooter.Text = "We are Available for Helping out in AV Bypassing";
            this.topPanel.Controls.Add(labelFooter);

            // Footer line
            Label labelLine = new Label();
            labelLine.BackColor = System.Drawing.Color.Cyan;
            labelLine.ForeColor = System.Drawing.Color.Cyan;
            labelLine.Location = new System.Drawing.Point(12, 675);
            labelLine.Name = "labelLine";
            labelLine.Size = new System.Drawing.Size(422, 1);
            labelLine.TabIndex = 98;
            this.topPanel.Controls.Add(labelLine);

            // sleepNum
            this.sleepNum.BackColor = System.Drawing.Color.Black;
            this.sleepNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sleepNum.Enabled = false;
            this.sleepNum.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.sleepNum.ForeColor = System.Drawing.Color.Lime;
            this.sleepNum.Location = new System.Drawing.Point(272, checkboxStartY + 25);
            this.sleepNum.Maximum = new decimal(new int[] {
            2147483647,
            0,
            0,
            0});
            this.sleepNum.Name = "sleepNum";
            this.sleepNum.Size = new System.Drawing.Size(120, 23);
            this.sleepNum.TabIndex = 33;

            // assemblyBtn
            this.assemblyBtn.BackColor = System.Drawing.Color.Black;
            this.assemblyBtn.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
            this.assemblyBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(0, 64, 0);
            this.assemblyBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(0, 32, 0);
            this.assemblyBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.assemblyBtn.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.assemblyBtn.ForeColor = System.Drawing.Color.Lime;
            this.assemblyBtn.Location = new System.Drawing.Point(28, checkboxStartY + 90);
            this.assemblyBtn.Name = "assemblyBtn";
            this.assemblyBtn.Size = new System.Drawing.Size(85, 29);
            this.assemblyBtn.TabIndex = 32;
            this.assemblyBtn.Text = "ASSEMBLY";
            this.assemblyBtn.UseVisualStyleBackColor = false;
            this.assemblyBtn.Click += new System.EventHandler(this.assemblyBtn_Click);

            // buildBtn
            this.buildBtn.BackColor = System.Drawing.Color.Black;
            this.buildBtn.Enabled = false;
            this.buildBtn.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.buildBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(64, 0, 0);
            this.buildBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(32, 0, 0);
            this.buildBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buildBtn.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.buildBtn.ForeColor = System.Drawing.Color.Red;
            this.buildBtn.Location = new System.Drawing.Point(324, checkboxStartY + 90);
            this.buildBtn.Name = "buildBtn";
            this.buildBtn.Size = new System.Drawing.Size(85, 29);
            this.buildBtn.TabIndex = 31;
            this.buildBtn.Text = "BUILD";
            this.buildBtn.UseVisualStyleBackColor = false;
            this.buildBtn.Click += new System.EventHandler(this.buildBtn_Click);

            // sleepChk
            this.sleepChk.AutoSize = true;
            this.sleepChk.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.sleepChk.ForeColor = System.Drawing.Color.Cyan;
            this.sleepChk.Location = new System.Drawing.Point(272, checkboxStartY);
            this.sleepChk.Name = "sleepChk";
            this.sleepChk.Size = new System.Drawing.Size(118, 19);
            this.sleepChk.TabIndex = 30;
            this.sleepChk.Text = "EXEC DELAY";
            this.sleepChk.UseVisualStyleBackColor = true;
            this.sleepChk.CheckedChanged += new System.EventHandler(this.sleepChk_CheckedChanged);

            // antiVM
            this.antiVM.AutoSize = true;
            this.antiVM.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.antiVM.ForeColor = System.Drawing.Color.Cyan;
            this.antiVM.Location = new System.Drawing.Point(150, checkboxStartY + 25);
            this.antiVM.Name = "antiVM";
            this.antiVM.Size = new System.Drawing.Size(74, 19);
            this.antiVM.TabIndex = 29;
            this.antiVM.Text = "ANTI-VM";
            this.antiVM.UseVisualStyleBackColor = true;

            // amsiBox
            this.amsiBox.AutoSize = true;
            this.amsiBox.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.amsiBox.ForeColor = System.Drawing.Color.Cyan;
            this.amsiBox.Location = new System.Drawing.Point(150, checkboxStartY);
            this.amsiBox.Name = "amsiBox";
            this.amsiBox.Size = new System.Drawing.Size(118, 19);
            this.amsiBox.TabIndex = 28;
            this.amsiBox.Text = "AMSI BYPASS";
            this.amsiBox.UseVisualStyleBackColor = true;

            // schtasksChk
            this.schtasksChk.AutoSize = true;
            this.schtasksChk.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.schtasksChk.ForeColor = System.Drawing.Color.Cyan;
            this.schtasksChk.Location = new System.Drawing.Point(28, checkboxStartY + 25);
            this.schtasksChk.Name = "schtasksChk";
            this.schtasksChk.Size = new System.Drawing.Size(90, 19);
            this.schtasksChk.TabIndex = 27;
            this.schtasksChk.Text = "SCHTASKS";
            this.schtasksChk.UseVisualStyleBackColor = true;
            this.schtasksChk.CheckedChanged += new System.EventHandler(this.schtasksBox_CheckedChanged);

            // regeditChk
            this.regeditChk.AutoSize = true;
            this.regeditChk.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.regeditChk.ForeColor = System.Drawing.Color.Cyan;
            this.regeditChk.Location = new System.Drawing.Point(28, checkboxStartY);
            this.regeditChk.Name = "regeditChk";
            this.regeditChk.Size = new System.Drawing.Size(82, 19);
            this.regeditChk.TabIndex = 26;
            this.regeditChk.Text = "REGISTRY";
            this.regeditChk.UseVisualStyleBackColor = true;
            this.regeditChk.CheckedChanged += new System.EventHandler(this.regeditChk_CheckedChanged);

            // label13
            this.label13.BackColor = System.Drawing.Color.Cyan;
            this.label13.ForeColor = System.Drawing.Color.Cyan;
            this.label13.Location = new System.Drawing.Point(12, checkboxStartY + 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(422, 1);
            this.label13.TabIndex = 25;
            this.label13.Text = "label13";

            // label12
            this.label12.BackColor = System.Drawing.Color.Cyan;
            this.label12.ForeColor = System.Drawing.Color.Cyan;
            this.label12.Location = new System.Drawing.Point(12, checkboxStartY - 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(422, 1);
            this.label12.TabIndex = 24;
            this.label12.Text = "label12";

            // runpeTypeBox
            this.runpeTypeBox.BackColor = System.Drawing.Color.Black;
            this.runpeTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.runpeTypeBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.runpeTypeBox.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.runpeTypeBox.ForeColor = System.Drawing.Color.Lime;
            this.runpeTypeBox.FormattingEnabled = true;
            this.runpeTypeBox.Items.AddRange(new object[] {
            "RegAsm",
            "Itself"});
            this.runpeTypeBox.Location = new System.Drawing.Point(28, 475);
            this.runpeTypeBox.Name = "runpeTypeBox";
            this.runpeTypeBox.Size = new System.Drawing.Size(381, 23);
            this.runpeTypeBox.TabIndex = 23;

            // label11
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Cyan;
            this.label11.Location = new System.Drawing.Point(24, 450);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(152, 17);
            this.label11.TabIndex = 22;
            this.label11.Text = "INJECTION TYPE:";

            // encryptionTypeBox
            this.encryptionTypeBox.BackColor = System.Drawing.Color.Black;
            this.encryptionTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.encryptionTypeBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.encryptionTypeBox.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.encryptionTypeBox.ForeColor = System.Drawing.Color.Lime;
            this.encryptionTypeBox.FormattingEnabled = true;
            this.encryptionTypeBox.Items.AddRange(new object[] {
            "AES",
            "XOR"});
            this.encryptionTypeBox.Location = new System.Drawing.Point(28, 375);
            this.encryptionTypeBox.Name = "encryptionTypeBox";
            this.encryptionTypeBox.Size = new System.Drawing.Size(381, 23);
            this.encryptionTypeBox.TabIndex = 21;

            // label10
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Cyan;
            this.label10.Location = new System.Drawing.Point(24, 350);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "ENCRYPTION TYPE:";

            // label9
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Cyan;
            this.label9.Location = new System.Drawing.Point(24, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "REGISTRY NAME:";

            // regeditNameTxt
            this.regeditNameTxt.BackColor = System.Drawing.Color.Black;
            this.regeditNameTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regeditNameTxt.Enabled = false;
            this.regeditNameTxt.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.regeditNameTxt.ForeColor = System.Drawing.Color.Lime;
            this.regeditNameTxt.Location = new System.Drawing.Point(28, 325);
            this.regeditNameTxt.Name = "regeditNameTxt";
            this.regeditNameTxt.Size = new System.Drawing.Size(381, 23);
            this.regeditNameTxt.TabIndex = 18;

            // label8
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Cyan;
            this.label8.Location = new System.Drawing.Point(24, 245);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(184, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "SCHEDULED TASKS NAME:";

            // schtasksNameTxt
            this.schtasksNameTxt.BackColor = System.Drawing.Color.Black;
            this.schtasksNameTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.schtasksNameTxt.Enabled = false;
            this.schtasksNameTxt.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.schtasksNameTxt.ForeColor = System.Drawing.Color.Lime;
            this.schtasksNameTxt.Location = new System.Drawing.Point(28, 270);
            this.schtasksNameTxt.Name = "schtasksNameTxt";
            this.schtasksNameTxt.Size = new System.Drawing.Size(381, 23);
            this.schtasksNameTxt.TabIndex = 16;

            // label7
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Cyan;
            this.label7.Location = new System.Drawing.Point(24, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "FOLDER NAME:";

            // foldernameTxt
            this.foldernameTxt.BackColor = System.Drawing.Color.Black;
            this.foldernameTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.foldernameTxt.Enabled = false;
            this.foldernameTxt.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.foldernameTxt.ForeColor = System.Drawing.Color.Lime;
            this.foldernameTxt.Location = new System.Drawing.Point(28, 220);
            this.foldernameTxt.Name = "foldernameTxt";
            this.foldernameTxt.Size = new System.Drawing.Size(381, 23);
            this.foldernameTxt.TabIndex = 14;

            // specialBox
            this.specialBox.BackColor = System.Drawing.Color.Black;
            this.specialBox.Enabled = false;
            this.specialBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.specialBox.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.specialBox.ForeColor = System.Drawing.Color.Lime;
            this.specialBox.FormattingEnabled = true;
            this.specialBox.Location = new System.Drawing.Point(28, 170);
            this.specialBox.Name = "specialBox";
            this.specialBox.Size = new System.Drawing.Size(381, 23);
            this.specialBox.TabIndex = 13;

            // label6
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Cyan;
            this.label6.Location = new System.Drawing.Point(24, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "SPECIAL FOLDER DIR:";

            // label5
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Cyan;
            this.label5.Location = new System.Drawing.Point(24, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "FILE NAME:";

            // filenameTxt
            this.filenameTxt.BackColor = System.Drawing.Color.Black;
            this.filenameTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.filenameTxt.Enabled = false;
            this.filenameTxt.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.filenameTxt.ForeColor = System.Drawing.Color.Lime;
            this.filenameTxt.Location = new System.Drawing.Point(28, 120);
            this.filenameTxt.Name = "filenameTxt";
            this.filenameTxt.Size = new System.Drawing.Size(381, 23);
            this.filenameTxt.TabIndex = 9;

            // browsePayloadBtn
            this.browsePayloadBtn.BackColor = System.Drawing.Color.Black;
            this.browsePayloadBtn.FlatAppearance.BorderColor = System.Drawing.Color.Cyan;
            this.browsePayloadBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(0, 64, 0);
            this.browsePayloadBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(0, 32, 0);
            this.browsePayloadBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.browsePayloadBtn.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Bold);
            this.browsePayloadBtn.ForeColor = System.Drawing.Color.Lime;
            this.browsePayloadBtn.Location = new System.Drawing.Point(324, 65);
            this.browsePayloadBtn.Name = "browsePayloadBtn";
            this.browsePayloadBtn.Size = new System.Drawing.Size(85, 29);
            this.browsePayloadBtn.TabIndex = 7;
            this.browsePayloadBtn.Text = "BROWSE";
            this.browsePayloadBtn.UseVisualStyleBackColor = false;
            this.browsePayloadBtn.Click += new System.EventHandler(this.browsePayloadBtn_Click);

            // label4
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Consolas", 10F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Cyan;
            this.label4.Location = new System.Drawing.Point(24, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "PAYLOAD:";

            // payloadTxt
            this.payloadTxt.BackColor = System.Drawing.Color.Black;
            this.payloadTxt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.payloadTxt.Font = new System.Drawing.Font("Consolas", 9.5F);
            this.payloadTxt.ForeColor = System.Drawing.Color.Lime;
            this.payloadTxt.Location = new System.Drawing.Point(28, 65);
            this.payloadTxt.Name = "payloadTxt";
            this.payloadTxt.Size = new System.Drawing.Size(282, 23);
            this.payloadTxt.TabIndex = 5;

            // label3
            this.label3.BackColor = System.Drawing.Color.Cyan;
            this.label3.ForeColor = System.Drawing.Color.Cyan;
            this.label3.Location = new System.Drawing.Point(12, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(422, 1);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";

            // label2
            this.label2.BackColor = System.Drawing.Color.Cyan;
            this.label2.ForeColor = System.Drawing.Color.Cyan;
            this.label2.Location = new System.Drawing.Point(12, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(422, 1);
            this.label2.TabIndex = 3;
            this.label2.Text = "label2";

            // exitBox
            this.exitBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exitBox.Image = global::Shadow-Crypt.Properties.Resources.close_button;
            this.exitBox.Location = new System.Drawing.Point(415, 9);
            this.exitBox.Name = "exitBox";
            this.exitBox.Size = new System.Drawing.Size(20, 20);
            this.exitBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.exitBox.TabIndex = 2;
            this.exitBox.TabStop = false;
            this.exitBox.Click += new System.EventHandler(this.exitBox_Click);

            // minimizeBox
            this.minimizeBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimizeBox.Image = global::Shadow-Crypt.Properties.Resources.minus_sign;
            this.minimizeBox.Location = new System.Drawing.Point(389, 9);
            this.minimizeBox.Name = "minimizeBox";
            this.minimizeBox.Size = new System.Drawing.Size(20, 20);
            this.minimizeBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.minimizeBox.TabIndex = 1;
            this.minimizeBox.TabStop = false;
            this.minimizeBox.Click += new System.EventHandler(this.minimizeBox_Click);

            // MainFrm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(446, 750);
            this.Controls.Add(this.topPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainFrm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SHADOWCRYPT";
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sleepNum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.exitBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minimizeBox)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.PictureBox minimizeBox;
        private System.Windows.Forms.PictureBox exitBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox payloadTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button browsePayloadBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox specialBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox filenameTxt;
        private System.Windows.Forms.CheckBox amsiBox;
        private System.Windows.Forms.CheckBox schtasksChk;
        private System.Windows.Forms.CheckBox regeditChk;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox runpeTypeBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox encryptionTypeBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox regeditNameTxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox schtasksNameTxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox foldernameTxt;
        private System.Windows.Forms.CheckBox sleepChk;
        private System.Windows.Forms.CheckBox antiVM;
        private System.Windows.Forms.Button assemblyBtn;
        private System.Windows.Forms.Button buildBtn;
        private System.Windows.Forms.NumericUpDown sleepNum;
        private System.Windows.Forms.Label labelAVBypass;
        private System.Windows.Forms.ComboBox comboBoxAVBypass;
    }
}