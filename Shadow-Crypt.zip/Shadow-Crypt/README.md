<div align="center">
  <h1>
      Shadow-Crypt
  </h1>
  <h4> Shadow-Crypt is an obfuscation tool for .NET and Native files created for security researchers and people who are learning.
    This application allows you to encrypt your payload to decrease scanners detection.</h4>
</div>

<div align="center">
  <h2>Authors</h2>
    Ajajjajk - Aries52
  <br/>
    XaFF - XaFF
</div>

<div align="center">
  <h2>Features</h2>
  <img src="https://github.com/XaFF-XaFF/Shadow-Crypt/blob/master/img/Shadow.png"></img
</div>
  
  AES256 and XOR encryption
  <br/>
 RegAsm or Itself process hollowing
  <br/>
 Scheduled tasks and registry startup
  <br/>
 Execution delay
  <br/>
 Simple obfuscator
  <br/>
 Assembly cloner
  <br/>
 AMSI Bypass (In maintenance)
  <br/>
 AntiVM
  <br/>
 
## Requirements
  dnlib https://github.com/0xd4d/dnlib#windows-pdbs
  IconExtractor https://github.com/jsakamoto/IconExtractor
  
## Disclaimer

The creators are not responsible for any actions or other damages caused, by this software.
Crypter is intended for educational purposes only and should not be used for any illegal purposes.
This software's purpose is not to be used malciously, or on other computer, who you are not an owner.
By downloading and using this software, you agree to above disclaimer 

## License

[MIT License](https://github.com/XaFF-XaFF/Shadow-Crypt/blob/master/LICENSE)
<br/>
Copyright (c) 2022 Talos
